export function ServiceIcon({ name }: { name: string }) {
  const stroke = { stroke: "currentColor", strokeWidth: 1.6, fill: "none", strokeLinecap: "round", strokeLinejoin: "round" } as const;
  switch (name) {
    case "shield":
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" {...stroke}>
          <path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z" />
          <path d="M9 12l2 2 4-4" />
        </svg>
      );
    case "certificate":
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" {...stroke}>
          <rect x="3" y="4" width="18" height="13" rx="2" />
          <path d="M7 9h10M7 12h6" />
          <path d="M9 17l-1 4 3-2 3 2-1-4" />
        </svg>
      );
    case "book":
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" {...stroke}>
          <path d="M4 5a2 2 0 012-2h13v16H6a2 2 0 00-2 2V5z" />
          <path d="M4 19a2 2 0 012-2h13" />
        </svg>
      );
    case "network":
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" {...stroke}>
          <circle cx="6" cy="6" r="2.5" />
          <circle cx="18" cy="6" r="2.5" />
          <circle cx="12" cy="18" r="2.5" />
          <path d="M8 7l3 9M16 7l-3 9M8 6h8" />
        </svg>
      );
    case "building":
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" {...stroke}>
          <rect x="4" y="3" width="11" height="18" rx="1" />
          <path d="M8 7h3M8 11h3M8 15h3" />
          <path d="M15 21v-7h5v7" />
        </svg>
      );
    case "scale":
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" {...stroke}>
          <path d="M12 3v18M6 7h12M6 7l-3 6a3 3 0 006 0l-3-6zM18 7l-3 6a3 3 0 006 0l-3-6z" />
          <path d="M8 21h8" />
        </svg>
      );
    case "gavel":
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" {...stroke}>
          <path d="M13 4l5 5-2 2-5-5 2-2z" />
          <path d="M9 8l5 5-6 6-5-5 6-6z" />
          <path d="M4 21h6" />
        </svg>
      );
    case "calculator":
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" {...stroke}>
          <rect x="5" y="3" width="14" height="18" rx="2" />
          <path d="M8 7h8M8 11h2M12 11h2M16 11h0M8 15h2M12 15h2M16 15h0" />
        </svg>
      );
    case "trending-up":
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" {...stroke}>
          <path d="M3 17l6-6 4 4 8-8" />
          <path d="M15 7h6v6" />
        </svg>
      );
    case "heart-pulse":
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" {...stroke}>
          <path d="M20 8.5c0-2.5-2-4.5-4.5-4.5-1.4 0-2.7.7-3.5 1.8C11.2 4.7 9.9 4 8.5 4 6 4 4 6 4 8.5c0 4.5 8 10.5 8 10.5s8-6 8-10.5z" />
          <path d="M6 10h2.5l1.5-2 2 4 1.5-2H16" />
        </svg>
      );
    case "zap":
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" {...stroke}>
          <path d="M13 2L4 14h6l-1 8 9-12h-6l1-8z" />
        </svg>
      );
    case "presentation":
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" {...stroke}>
          <rect x="3" y="4" width="18" height="12" rx="1" />
          <path d="M8 20l4-4 4 4M12 16v0" />
        </svg>
      );
    case "rocket":
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" {...stroke}>
          <path d="M12 2c3 1.5 5 5 5 9 0 2-1 4-1 4l-4 2-4-2s-1-2-1-4c0-4 2-7.5 5-9z" />
          <circle cx="12" cy="10" r="1.6" />
          <path d="M9 17l-2 4M15 17l2 4" />
        </svg>
      );
    case "users":
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" {...stroke}>
          <circle cx="9" cy="8" r="3" />
          <path d="M3 20c0-3 2.7-5 6-5s6 2 6 5" />
          <circle cx="17" cy="9" r="2.4" />
          <path d="M15.5 15.2c2.4.3 4.5 1.9 4.5 4.8" />
        </svg>
      );
    case "badge-check":
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" {...stroke}>
          <path d="M12 2l2.4 1.6 2.8-.4 1 2.6 2.6 1-.4 2.8L22 12l-1.6 2.4.4 2.8-2.6 1-1 2.6-2.8-.4L12 22l-2.4-1.6-2.8.4-1-2.6-2.6-1 .4-2.8L2 12l1.6-2.4-.4-2.8 2.6-1 1-2.6 2.8.4L12 2z" />
          <path d="M9 12l2 2 4-4" />
        </svg>
      );
    case "radio":
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" {...stroke}>
          <circle cx="12" cy="14" r="3" />
          <path d="M4 14a8 8 0 0116 0" />
          <path d="M2 14a10 10 0 0120 0" />
          <path d="M12 14v-1" />
        </svg>
      );
    default:
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" {...stroke}>
          <circle cx="12" cy="12" r="8" />
        </svg>
      );
  }
}