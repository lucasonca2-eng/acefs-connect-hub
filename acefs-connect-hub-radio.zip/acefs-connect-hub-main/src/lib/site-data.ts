export const NAV = [
  { label: "Início", to: "/" },
  { label: "Quem Somos", to: "/quem-somos" },
  { label: "Serviços", to: "/servicos" },
  { label: "Notícias", to: "/noticias" },
  { label: "Contato", to: "/contato" },
] as const;

export const SERVICES = [
  {
    slug: "junta-comercial",
    title: "Junta Comercial (JUCEB)",
    short: "Convênio direto com a Junta Comercial da Bahia.",
    desc: "Abertura, alteração e baixa de empresas com atendimento facilitado via convênio ACEFS–JUCEB, sem precisar sair de Feira de Santana.",
    icon: "building",
  },
  {
    slug: "consultas-boa-vista",
    title: "Consultas e Negativações (Boa Vista)",
    short: "Consultas de crédito e proteção contra inadimplência.",
    desc: "Consultas de crédito, análise de risco e proteção contra inadimplência com a base do SCPC / Boa Vista, referência nacional em inteligência de crédito.",
    icon: "shield",
  },
  {
    slug: "certificado-digital",
    title: "Certificado Digital e de Origem",
    short: "Emissão de e-CPF e e-CNPJ com atendimento ágil.",
    desc: "Emissão presencial ou na sua empresa, com validade jurídica reconhecida e agilidade para obrigações fiscais.",
    icon: "certificate",
  },
  {
    slug: "camara-mediacao-arbitragem",
    title: "Câmara de Mediação e Arbitragem",
    short: "Resolução de conflitos empresariais fora do Judiciário.",
    desc: "Mediação e arbitragem para disputas comerciais, com mais agilidade e menor custo do que o processo judicial tradicional.",
    icon: "scale",
  },
  {
    slug: "assessoria-juridica",
    title: "Assessoria Jurídica",
    short: "Orientação jurídica especializada para associados.",
    desc: "Suporte em questões trabalhistas, tributárias, contratuais e regulatórias que afetam o dia a dia do seu negócio.",
    icon: "gavel",
  },
  {
    slug: "contabilidade-empresarial",
    title: "Contabilidade Empresarial",
    short: "Suporte contábil para associados de todos os portes.",
    desc: "Orientação e serviços contábeis para manter sua empresa em dia com as obrigações fiscais.",
    icon: "calculator",
  },
  {
    slug: "acesso-a-credito",
    title: "Acesso à Crédito",
    short: "Facilitação de linhas de crédito para o associado.",
    desc: "Orientação e articulação para acesso a linhas de crédito voltadas ao capital de giro e investimento das empresas locais.",
    icon: "trending-up",
  },
  {
    slug: "plano-saude-empresarial",
    title: "Plano de Saúde Empresarial",
    short: "Condições especiais em planos de saúde para associados.",
    desc: "Convênios com operadoras de saúde, oferecendo condições diferenciadas para empresas associadas e seus colaboradores.",
    icon: "heart-pulse",
  },
  {
    slug: "mercado-livre-energia",
    title: "MLE · Mercado Livre de Energia",
    short: "Redução de custos com energia elétrica.",
    desc: "Orientação para migração ao Mercado Livre de Energia, com potencial de redução significativa na conta de luz da empresa.",
    icon: "zap",
  },
  {
    slug: "auditorio-eventos",
    title: "Auditórios para Eventos e Treinamentos",
    short: "Dois auditórios próprios para locação e capacitação.",
    desc: "Estrutura própria para palestras, treinamentos, assembleias e eventos corporativos no coração de Feira de Santana.",
    icon: "presentation",
  },
  {
    slug: "cursos",
    title: "Cursos & Capacitação",
    short: "Formação contínua para empresários e equipes.",
    desc: "Programas em gestão, vendas, finanças e liderança, com palestras técnicas e motivacionais para associados.",
    icon: "book",
  },
  {
    slug: "programa-empreender",
    title: "Programa Empreender",
    short: "Metodologia nacional de fortalecimento do comércio local.",
    desc: "Programa Empreender (rede CACB) para capacitação, gestão associativa e desenvolvimento de núcleos setoriais.",
    icon: "rocket",
  },
  {
    slug: "cmec",
    title: "CMEC · Mulher Empreendedora e Cultura",
    short: "Conselho dedicado à mulher empreendedora e à cultura local.",
    desc: "Espaço institucional de apoio, capacitação e representação para empreendedoras e para a agenda cultural de Feira de Santana.",
    icon: "users",
  },
  {
    slug: "registro-marcas-patentes",
    title: "Registro de Marcas e Patentes",
    short: "Proteção jurídica para marcas e produtos da sua empresa.",
    desc: "Assessoria completa para registro de marcas e patentes junto ao INPI, protegendo a identidade do seu negócio.",
    icon: "badge-check",
  },
  {
    slug: "encontros-negocios",
    title: "Encontros de Negócios",
    short: "Rodadas de negócios entre associados e parceiros.",
    desc: "Eventos de networking que conectam lideranças, geram parcerias e aproximam empresas de diferentes setores.",
    icon: "network",
  },
  {
    slug: "programa-radio",
    title: "Rádio ACEFS",
    short: "Programa institucional ao vivo sobre o comércio local.",
    desc: "Transmissão ao vivo com boletins, entrevistas e pauta econômica direto da sede da associação para todo o empresariado feirense.",
    icon: "radio",
  },
] as const;

export const NEWS = [
  {
    slug: "acefs-reune-liderancas-varejo",
    category: "Encontro",
    date: "12 Jun 2026",
    title: "ACEFS reúne lideranças para debater o futuro do varejo regional",
    excerpt: "Mais de 200 empresários no auditório discutiram crédito, logística urbana e digitalização do comércio.",
  },
  {
    slug: "cursos-gratuitos-julho",
    category: "Formação",
    date: "04 Jun 2026",
    title: "Nova rodada de cursos gratuitos para associados em julho",
    excerpt: "Inscrições abertas para capacitações em gestão financeira e marketing digital.",
  },
  {
    slug: "sebrae-acefs-consultoria",
    category: "Parceria",
    date: "28 Mai 2026",
    title: "Sebrae e ACEFS ampliam consultoria gratuita às MPEs",
    excerpt: "Atendimento semanal começa em junho na sede da associação.",
  },
  {
    slug: "assembleia-2026",
    category: "Institucional",
    date: "15 Mai 2026",
    title: "Assembleia geral aprova diretrizes para o próximo biênio",
    excerpt: "Associados definem prioridades em representação, formação e serviços digitais.",
  },
  {
    slug: "feira-negocios",
    category: "Evento",
    date: "02 Mai 2026",
    title: "Feira de Negócios ACEFS reúne 80 expositores no centro",
    excerpt: "Rodadas de compras conectaram indústrias locais a compradores de todo o Nordeste.",
  },
  {
    slug: "premio-mercado",
    category: "Reconhecimento",
    date: "22 Abr 2026",
    title: "Prêmio Mérito do Comércio homenageia 12 empresas centenárias",
    excerpt: "Cerimônia celebrou negócios que ajudaram a construir Feira de Santana.",
  },
] as const;

export const PARTNERS = [
  "CACB",
  "FACEB",
  "Sebrae Bahia",
  "Boa Vista",
  "JUCEB",
  "Governo da Bahia",
] as const;

export const STATS = [
  { n: "81", suffix: "anos", label: "de atuação contínua" },
  { n: "2.400", suffix: "+", label: "empresas associadas" },
  { n: "20", suffix: "+", label: "serviços e benefícios" },
  { n: "2", suffix: "", label: "auditórios próprios" },
] as const;

export const ORG = {
  founded: "17 de junho de 1945",
  foundedYear: "1945",
  president: "Genildo Oliveira de Melo",
  address: ["Largo São Francisco, nº 43", "Kalilândia — Feira de Santana, BA", "CEP 44.025-110"],
  phone: "(75) 3211-7446",
  phoneHref: "+557532117446",
  email: "acefs@acefs.com.br",
  mission:
    "Representar e defender, com ética, os interesses empresariais, prestando serviços, fomentando e empreendendo ações que efetivem o desenvolvimento da entidade e da comunidade.",
  vision:
    "Ser vista como uma das maiores entidades representativas da Bahia, na promoção de ações voltadas para o empresariado e o desenvolvimento sócio-econômico da região.",
} as const;